#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_USERS 10
#define MAX_CUSTOMERS 10
#define MAX_NAME_LENGTH 50
#define MAX_IBAN_LENGTH 17

// Structure to hold customer information
typedef struct {
    char username[MAX_NAME_LENGTH];
    char password[MAX_NAME_LENGTH];
    char IBAN[MAX_IBAN_LENGTH];
    int civilID;
    int yearOfBirth;
    float salary;
    float balance;
} Customer;

// Structure to hold login information
typedef struct {
    char username[MAX_NAME_LENGTH];
    char password[MAX_NAME_LENGTH];
} User;

// Function prototypes
int countRowsInFile(const char *filename);
void readCustomersFromFile(const char *filename, Customer *customers, int numCustomers);
void readUsersFromFile(const char *filename, User *users, int numUsers);
void displayAdminMenu();
void displayUserMenu();
void checkPersonalDetails(const Customer *customers, int numCustomers, const char *username);
void updatePersonalDetails(Customer *customers, int numCustomers, const char *username);
void transferMoney(Customer *customers, int numCustomers, const char *username);
void withdraw(Customer *customers, int numCustomers, const char *username);
void deposit(Customer *customers, int numCustomers, const char *username);
void checkLoanEligibility(const Customer *customers, int numCustomers, const char *username);

int main() {
    // Variables
    int numCustomers, numUsers;
    Customer *customers;
    User *users;
    char username[MAX_NAME_LENGTH], password[MAX_NAME_LENGTH];
    int choice;
    char adminUsername[MAX_NAME_LENGTH];

    // Read number of rows in customer and login files
    numCustomers = countRowsInFile("customers.txt");
    numUsers = countRowsInFile("login.txt");

    // Dynamically allocate memory for arrays of structures
    customers = (Customer *)malloc(numCustomers * sizeof(Customer));
    users = (User *)malloc(numUsers * sizeof(User));

    // Read data from files into arrays of structures
    readCustomersFromFile("customers.txt", customers, numCustomers);
    readUsersFromFile("login.txt", users, numUsers);

    // Get admin username
    strcpy(adminUsername, users[0].username);

    // Login
    printf("Enter username: ");
    scanf("%s", username);
    printf("Enter password: ");
    scanf("%s", password);

    // Check if username and password match
    int isAdmin = 0;
    for (int i = 0; i < numUsers; i++) {
        if (strcmp(username, users[i].username) == 0 && strcmp(password, users[i].password) == 0) {
            if (i == 0) {
                isAdmin = 1;
            }
            break;
        }
    }

    if (isAdmin) {
        // Admin user
        do {
            displayAdminMenu();
            printf("Enter your choice: ");
            scanf("%d", &choice);
            switch (choice) {
                case 1:
                    // Check users
                    printf("\nUsers List:\n");
                    for (int i = 0; i < numUsers; i++) {
                        printf("Username: %s\n", users[i].username);
                        // You may print other user details if needed
                    }
                    break;
                case 2:
                    // Check customers
                    printf("\nCustomers List:\n");
                    for (int i = 0; i < numCustomers; i++) {
                        printf("Username: %s\n", customers[i].username);
                        // You may print other customer details if needed
                    }
                    break;
                case 3:
                    // Exit
                    printf("Exiting program...\n");
                    break;
                default:
                    printf("Invalid option.\n");
            }

        } while (choice != 3);
    } else {
        // Regular user
        do {
            displayUserMenu();
            printf("Enter your choice: ");
            scanf("%d", &choice);
            switch (choice) {
                case 1:
                    checkPersonalDetails(customers, numCustomers, username);
                    break;
                case 2:
                    updatePersonalDetails(customers, numCustomers, username);
                    break;
                case 3:
                    transferMoney(customers, numCustomers, username);
                    break;
                case 4:
                    withdraw(customers, numCustomers, username);
                    break;
                case 5:
                    deposit(customers, numCustomers, username);
                    break;
                case 6:
                    checkLoanEligibility(customers, numCustomers, username);
                    break;
                case 7:
                    // Exit
                    printf("Exiting program...\n");
                    break;
                default:
                    printf("Invalid option.\n");
            }
        } while (choice != 7);
    }

    // Free dynamically allocated memory
    free(customers);
    free(users);

    return 0;
}

// Function to count the number of rows in a file
int countRowsInFile(const char *filename) {
    FILE *file = fopen(filename, "r");
    if (file == NULL) {
        printf("Error opening file %s.\n", filename);
        exit(1);
    }
    int count = 0;
    char line[100];
    while (fgets(line, sizeof(line), file) != NULL) {
        count++;
    }
    fclose(file);
    return count;
}

// Function to read customer data from file into array of structures
void readCustomersFromFile(const char *filename, Customer *customers, int numCustomers) {
    FILE *file = fopen(filename, "r");
    if (file == NULL) {
        printf("Error opening file %s.\n", filename);
        exit(1);
    }
    for (int i = 0; i < numCustomers; i++) {
        fscanf(file, "%s %s %s %d %d %f %f", customers[i].username, customers[i].password, customers[i].IBAN, &customers[i].civilID, &customers[i].yearOfBirth, &customers[i].salary, &customers[i].balance);
    }
    fclose(file);
}

// Function to read user data from file into array of structures
void readUsersFromFile(const char *filename, User *users, int numUsers) {
    FILE *file = fopen(filename, "r");
    if (file == NULL) {
        printf("Error opening file %s.\n", filename);
        exit(1);
    }
    for (int i = 0; i < numUsers; i++) {
        fscanf(file, "%s %s", users[i].username, users[i].password);
    }
    fclose(file);
}

// Function to display admin menu
void displayAdminMenu() {
    printf("\nWelcome!\n");
    printf("Please select:\n");
    printf("1. Check users.\n");
    printf("2. Check customers.\n");
    printf("3. Exit.\n");
}

// Function to display regular user menu
void displayUserMenu() {
    printf("\nWelcome!\n");
    printf("Please select:\n");
    printf("1. Check Personal Details\n");
    printf("2. Update Personal Details\n");
    printf("3. Transfer money\n");
    printf("4. Withdraw\n");
    printf("5. Deposit\n");
    printf("6. Loan Eligibility\n");
    printf("7. Log out\n");
}

// Function to check personal details
void checkPersonalDetails(const Customer *customers, int numCustomers, const char *username) {
    int found = 0;
    for (int i = 0; i < numCustomers; i++) {
        if (strcmp(customers[i].username, username) == 0) {
            found = 1;
            printf("\nPersonal Details:\n");
            printf("Username: %s\n", customers[i].username);
            printf("IBAN: %s\n", customers[i].IBAN);
            printf("Civil ID: %d\n", customers[i].civilID);
            printf("Year of Birth: %d\n", customers[i].yearOfBirth);
            printf("Salary: %.2f\n", customers[i].salary);
            printf("Balance: %.2f\n", customers[i].balance);
            break;
        }
    }
    if (!found) {
        printf("Customer with username %s not found.\n", username);
    }
}


// Function to update personal details
void updatePersonalDetails(Customer *customers, int numCustomers, const char *username) {
    int found = 0;
    for (int i = 0; i < numCustomers; i++) {
        if (strcmp(customers[i].username, username) == 0) {
            found = 1;
            printf("\nEnter new personal details:\n");
            printf("IBAN: ");
            scanf("%s", customers[i].IBAN);
            printf("Civil ID: ");
            scanf("%d", &customers[i].civilID);
            printf("Year of Birth: ");
            scanf("%d", &customers[i].yearOfBirth);
            printf("Salary: ");
            scanf("%f", &customers[i].salary);
            printf("Balance: ");
            scanf("%f", &customers[i].balance);
            printf("Personal details updated successfully.\n");
            break;
        }
    }
    if (!found) {
        printf("Customer with username %s not found.\n", username);
    }
}


// Function to transfer money
void transferMoney(Customer *customers, int numCustomers, const char *username) {
    char recipientIBAN[MAX_IBAN_LENGTH];
    float amount;
    int senderIndex = -1, recipientIndex = -1;

    // Prompt user for recipient's IBAN and amount to transfer
    printf("\nEnter recipient's IBAN: ");
    scanf("%s", recipientIBAN);
    printf("Enter amount to transfer: ");
    scanf("%f", &amount);

    // Find sender's account
    for (int i = 0; i < numCustomers; i++) {
        if (strcmp(customers[i].username, username) == 0) {
            senderIndex = i;
            break;
        }
    }

    // Find recipient's account
    for (int i = 0; i < numCustomers; i++) {
        if (strcmp(customers[i].IBAN, recipientIBAN) == 0) {
            recipientIndex = i;
            break;
        }
    }

    // Check if sender and recipient accounts were found
    if (senderIndex == -1) {
        printf("Sender with username %s not found.\n", username);
        return;
    }
    if (recipientIndex == -1) {
        printf("Recipient with IBAN %s not found.\n", recipientIBAN);
        return;
    }

    // Check if sender has sufficient balance
    if (customers[senderIndex].balance < amount) {
        printf("Not enough funds in sender's account.\n");
        return;
    }

    // Update balances
    customers[senderIndex].balance -= amount;
    customers[recipientIndex].balance += amount;

    printf("Transfer successful. Updated balances:\n");
    printf("%s's balance: %.2f\n", customers[senderIndex].username, customers[senderIndex].balance);
    printf("%s's balance: %.2f\n", customers[recipientIndex].username, customers[recipientIndex].balance);
}

// Function to withdraw money
void withdraw(Customer *customers, int numCustomers, const char *username) {
    float amount;
    int customerIndex = -1;

    // Prompt user for amount to withdraw
    printf("\nEnter amount to withdraw: ");
    scanf("%f", &amount);

    // Find customer's account
    for (int i = 0; i < numCustomers; i++) {
        if (strcmp(customers[i].username, username) == 0) {
            customerIndex = i;
            break;
        }
    }

    // Check if customer account was found
    if (customerIndex == -1) {
        printf("Customer with username %s not found.\n", username);
        return;
    }

    // Check if customer has sufficient balance
    if (customers[customerIndex].balance < amount) {
        printf("Not enough funds in customer's account.\n");
        return;
    }

    // Update balance
    customers[customerIndex].balance -= amount;

    printf("Withdrawal successful. Updated balance: %.2f\n", customers[customerIndex].balance);
}

// Function to deposit money
void deposit(Customer *customers, int numCustomers, const char *username) {
    float amount;
    int customerIndex = -1;

    // Prompt user for amount to deposit
    printf("\nEnter amount to deposit: ");
    scanf("%f", &amount);

    // Find customer's account
    for (int i = 0; i < numCustomers; i++) {
        if (strcmp(customers[i].username, username) == 0) {
            customerIndex = i;
            break;
        }
    }

    // Check if customer account was found
    if (customerIndex == -1) {
        printf("Customer with username %s not found.\n", username);
        return;
    }

    // Update balance
    customers[customerIndex].balance += amount;

    printf("Deposit successful. Updated balance: %.2f\n", customers[customerIndex].balance);
}

// Function to check loan eligibility
void checkLoanEligibility(const Customer *customers, int numCustomers, const char *username) {
    float requestedLoanAmount;
    int customerIndex = -1;

    // Prompt user for requested loan amount
    printf("\nEnter requested loan amount: ");
    scanf("%f", &requestedLoanAmount);

    // Find customer's account
    for (int i = 0; i < numCustomers; i++) {
        if (strcmp(customers[i].username, username) == 0) {
            customerIndex = i;
            break;
        }
    }

    // Check if customer account was found
    if (customerIndex == -1) {
        printf("Customer with username %s not found.\n", username);
        return;
    }

    // Check loan eligibility criteria
    if (customers[customerIndex].balance >= 2 * requestedLoanAmount) {
        printf("Congratulations! You are eligible for a loan.\n");
    } else {
        printf("Sorry, you are not eligible for a loan.\n");
    }
}
